const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

function authHeader() {
  const token = localStorage.getItem("token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// -------- Auth --------
export async function login(email: string, password: string) {
  const res = await fetch(`${API}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) throw new Error((await res.json()).message || "Login failed");
  return res.json(); // { token, user }
}

export async function register(data: {name: string; email: string; password: string; role?: "student"|"professor"|"admin"}) {
  const res = await fetch(`${API}/api/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error((await res.json()).message || "Register failed");
  return res.json();
}

export async function me() {
  const res = await fetch(`${API}/api/auth/me`, { headers: { ...authHeader() } });
  if (!res.ok) throw new Error("Not authenticated");
  return res.json();
}

// -------- Courses --------
export async function listCourses(q?: string) {
  const url = new URL(`${API}/api/courses`);
  if (q) url.searchParams.set("q", q);
  const res = await fetch(url, { headers: { ...authHeader() } });
  if (!res.ok) throw new Error("Failed to load courses");
  return res.json();
}

export async function createCourse(payload: {title:string; code:string; department:string; description?:string}) {
  const res = await fetch(`${API}/api/courses`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeader() },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Create course failed");
  return res.json();
}

export async function enroll(courseId: string) {
  const res = await fetch(`${API}/api/courses/${courseId}/enroll`, {
    method: "POST",
    headers: { ...authHeader() },
  });
  if (!res.ok) throw new Error("Enroll failed");
  return res.json();
}

// -------- Materials --------
export async function listMaterials(courseId: string) {
  const res = await fetch(`${API}/api/courses/${courseId}/materials`, { headers: { ...authHeader() } });
  if (!res.ok) throw new Error("Failed to load materials");
  return res.json();
}

// -------- Assignments --------
export async function listAssignments(courseId: string) {
  const res = await fetch(`${API}/api/courses/${courseId}/assignments`, { headers: { ...authHeader() } });
  if (!res.ok) throw new Error("Failed to load assignments");
  return res.json();
}
