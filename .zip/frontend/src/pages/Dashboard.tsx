import { useSearchParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { listCourses } from "@/lib/api";

const Dashboard = () => {
  const [searchParams] = useSearchParams();
  const branch = searchParams.get("branch"); // e.g. "Computer Science and Engineering"
  const [courses, setCourses] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const data = await listCourses(); // you can pass a query: listCourses(branch)
        setCourses(data);
      } catch (e: any) {
        setError(e.message);
      }
    })();
  }, [branch]);

  // …render your cards; example:
  // courses.map(c => <div key={c._id}>{c.title} — {c.code}</div>)
};
export default Dashboard;
