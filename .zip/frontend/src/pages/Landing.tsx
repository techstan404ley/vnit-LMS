import { Button } from "@/components/ui/button";
import { GraduationCap, BookOpen, Home } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary via-secondary to-accent flex items-center justify-center p-4">
      <div className="max-w-4xl w-full text-center">
        <div className="mb-8">
          <Home className="w-16 h-16 text-white mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            VNIT Learning Management System
          </h1>
          <p className="text-lg text-white/90">
            Choose your portal to get started
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          <Button
            onClick={() => navigate("/auth?role=student")}
            className="h-40 flex-col gap-4 bg-white hover:bg-white/90 text-primary"
            size="lg"
          >
            <GraduationCap className="w-12 h-12" />
            <div>
              <div className="text-2xl font-bold">Student Panel</div>
              <div className="text-sm opacity-75">Access courses and materials</div>
            </div>
          </Button>

          <Button
            onClick={() => navigate("/auth?role=professor")}
            className="h-40 flex-col gap-4 bg-white hover:bg-white/90 text-secondary"
            size="lg"
          >
            <BookOpen className="w-12 h-12" />
            <div>
              <div className="text-2xl font-bold">Professor Panel</div>
              <div className="text-sm opacity-75">Manage courses and students</div>
            </div>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Landing;
