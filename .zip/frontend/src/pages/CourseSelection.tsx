const branches = [
  "Computer Science and Engineering",
  "Electronics and Communication Engineering",
  "Electrical and Electronics Engineering",
  "Information Technology",
  "Mechanical Engineering",
  "Civil Engineering",
  "Chemical Engineering",
  "Artificial Intelligence and Machine Learning",
];
