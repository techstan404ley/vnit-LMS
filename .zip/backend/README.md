# LMS Backend (Express + MongoDB)

## Features
- JWT Auth (student, professor, admin)
- Courses: create/list/enroll
- Materials: upload files or attach links
- Assignments: create/list; Submissions: upload
- Role-based access control

## Quick Start

1) Install Node (>=18) and MongoDB (local) OR create a MongoDB Atlas URI.

2) Copy `.env.example` to `.env` and edit values:
```
cp .env.example .env
```

3) Install deps:
```
npm install
```

4) Seed sample users/courses (optional):
```
npm run seed
```
Credentials created:
- admin@example.com / admin123 (admin)
- prof@example.com / prof123 (professor)
- student@example.com / student123 (student)

5) Start dev server:
```
npm run dev
```
Backend runs at `http://localhost:5000`.

### API Overview

#### Auth
- `POST /api/auth/register` { name, email, password, role? }
- `POST /api/auth/login` { email, password } -> { token, user }
- `GET /api/auth/me` (Bearer token)

#### Courses
- `GET /api/courses` (all, auth required)
- `POST /api/courses` (professor/admin) { title, code, department, description? }
- `POST /api/courses/:id/enroll` (student)
- `GET /api/courses/:id/students` (professor/admin)

#### Materials
- `POST /api/courses/:id/materials` (professor/admin) multipart/form-data with `file` OR JSON with `url`
- `GET /api/courses/:id/materials` (auth)

#### Assignments & Submissions
- `POST /api/courses/:id/assignments` (professor/admin) { title, description?, dueDate? }
- `GET /api/courses/:id/assignments` (auth)
- `POST /api/courses/assignments/:id/submit` (student) multipart/form-data with `file` and/or { notes }
- `GET /api/courses/assignments/:id/submissions` (professor/admin)

### Hooking the Frontend

Point your frontend API base to `http://localhost:5000` and send the JWT in header:
```
Authorization: Bearer <token>
```

For file uploads, use `multipart/form-data` with field name `file`.

### Notes
- Files are stored locally under `/uploads` and served at `/uploads/...`.
- Adjust CORS origin via `ORIGIN` in `.env` (e.g., `http://localhost:5173` for Vite).

