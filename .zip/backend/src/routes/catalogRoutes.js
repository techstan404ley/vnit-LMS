const router = require('express').Router();
const { auth } = require('../middleware/auth');
const { getSubjects } = require('../controllers/catalogController');

// Anyone logged in can fetch subjects
router.get('/', auth, getSubjects);

module.exports = router;
