const express = require('express');
const { body } = require('express-validator');
const { auth, permit } = require('../middleware/auth');
const {
  createCourse, listCourses, enroll, listStudents,
  addMaterial, getMaterials,
  createAssignment, getAssignments,
  submitAssignment, listSubmissions
} = require('../controllers/courseController');
const { materialUpload, submissionUpload } = require('../utils/multer');

const router = express.Router();

router.get('/', auth, listCourses);

router.post('/', auth, permit('professor', 'admin'), [
  body('title').notEmpty(),
  body('code').notEmpty(),
  body('department').notEmpty()
], createCourse);

router.post('/:id/enroll', auth, permit('student'), enroll);
router.get('/:id/students', auth, permit('professor', 'admin'), listStudents);

router.post('/:id/materials', auth, permit('professor', 'admin'), materialUpload.single('file'), addMaterial);
router.get('/:id/materials', auth, getMaterials);

router.post('/:id/assignments', auth, permit('professor', 'admin'), createAssignment);
router.get('/:id/assignments', auth, getAssignments);

router.post('/assignments/:id/submit', auth, permit('student'), submissionUpload.single('file'), submitAssignment);
router.get('/assignments/:id/submissions', auth, permit('professor', 'admin'), listSubmissions);

module.exports = router;
