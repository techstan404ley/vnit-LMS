const mongoose = require('mongoose');

const MaterialSchema = new mongoose.Schema({
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
  title: { type: String, required: true },
  filePath: { type: String },  // local path (uploads/materials/...)
  url: { type: String },       // optional external URL (e.g., Google Drive link)
  uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });

module.exports = mongoose.model('Material', MaterialSchema);
