const mongoose = require('mongoose');

const CatalogSchema = new mongoose.Schema({
  branchCode: { type: String, required: true },   // e.g., "CSE"
  branchName: { type: String, required: true },   // e.g., "Computer Science and Engineering"
  year: { type: String, required: true },         // "1st" | "2nd" | "3rd" | "4th"
  semester: { type: String, required: true },     // "1".."8"
  subjects: [
    {
      code: { type: String, required: true },     // e.g., "CS301"
      title: { type: String, required: true },    // e.g., "Data Structures"
      credits: { type: Number, default: 3 }
    }
  ]
}, { timestamps: true });

CatalogSchema.index({ branchCode: 1, year: 1, semester: 1 }, { unique: true });

module.exports = mongoose.model('Catalog', CatalogSchema);
