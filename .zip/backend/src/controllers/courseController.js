const { validationResult } = require('express-validator');
const Course = require('../models/Course');
const Material = require('../models/Material');
const Assignment = require('../models/Assignment');
const Submission = require('../models/Submission');

exports.createCourse = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { title, code, department, description } = req.body;
    const course = await Course.create({
      title, code, department, description, professor: req.user._id
    });
    res.status(201).json(course);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.listCourses = async (req, res) => {
  try {
    const { q } = req.query;
    const filter = q ? { title: new RegExp(q, 'i') } : {};
    const courses = await Course.find(filter).populate('professor', 'name email');
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.enroll = async (req, res) => {
  try {
    const { id } = req.params;
    const course = await Course.findById(id);
    if (!course) return res.status(404).json({ message: 'Course not found' });
    if (!course.students.includes(req.user._id)) {
      course.students.push(req.user._id);
      await course.save();
    }
    res.json({ message: 'Enrolled', courseId: id });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.listStudents = async (req, res) => {
  try {
    const { id } = req.params;
    const course = await Course.findById(id).populate('students', 'name email');
    if (!course) return res.status(404).json({ message: 'Course not found' });
    if (String(course.professor) !== String(req.user._id) && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }
    res.json(course.students);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.addMaterial = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, url } = req.body;
    const material = await Material.create({
      course: id,
      title,
      uploadedBy: req.user._id,
      filePath: req.file ? '/uploads/materials/' + req.file.filename : undefined,
      url: url || undefined
    });
    res.status(201).json(material);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getMaterials = async (req, res) => {
  try {
    const { id } = req.params;
    const items = await Material.find({ course: id }).sort({ createdAt: -1 });
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.createAssignment = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, dueDate } = req.body;
    const asg = await Assignment.create({
      course: id, title, description, dueDate, createdBy: req.user._id
    });
    res.status(201).json(asg);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAssignments = async (req, res) => {
  try {
    const { id } = req.params;
    const list = await Assignment.find({ course: id }).sort({ createdAt: -1 });
    res.json(list);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.submitAssignment = async (req, res) => {
  try {
    const { id } = req.params; // assignment id
    const { notes } = req.body;
    const payload = {
      assignment: id,
      student: req.user._id,
      notes: notes || ''
    };
    if (req.file) payload.filePath = '/uploads/submissions/' + req.file.filename;
    const sub = await require('../models/Submission').findOneAndUpdate(
      { assignment: id, student: req.user._id },
      payload,
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );
    res.status(201).json(sub);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.listSubmissions = async (req, res) => {
  try {
    const { id } = req.params; // assignment id
    const asg = await Assignment.findById(id).populate('course');
    if (!asg) return res.status(404).json({ message: 'Assignment not found' });
    if (String(asg.createdBy) !== String(req.user._id) && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }
    const subs = await require('../models/Submission')
      .find({ assignment: id })
      .populate('student', 'name email');
    res.json(subs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
