const Catalog = require('../models/Catalog');

exports.getSubjects = async (req, res) => {
  try {
    const { branch, year, semester } = req.query;
    if (!branch || !year || !semester) {
      return res.status(400).json({ message: 'branch, year, semester are required' });
    }
    const doc = await Catalog.findOne({
      branchCode: branch, year, semester
    });
    if (!doc) return res.json({ subjects: [] });
    res.json({ subjects: doc.subjects, branchName: doc.branchName });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};
