const multer = require('multer');
const path = require('path');
const fs = require('fs');

function makeStorage(folder) {
  const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      const dest = path.join(process.cwd(), 'uploads', folder);
      fs.mkdirSync(dest, { recursive: true });
      cb(null, dest);
    },
    filename: function (req, file, cb) {
      const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
      const ext = path.extname(file.originalname);
      cb(null, unique + ext);
    }
  });
  return storage;
}

const materialUpload = multer({ storage: makeStorage('materials') });
const submissionUpload = multer({ storage: makeStorage('submissions') });

module.exports = { materialUpload, submissionUpload };
