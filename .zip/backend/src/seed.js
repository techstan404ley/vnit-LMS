const dotenv = require('dotenv');
dotenv.config();
const connectDB = require('./config/db');
const User = require('./models/User');
const Course = require('./models/Course');

async function seed() {
  await connectDB(process.env.MONGO_URI);
  console.log('Seeding...');

  await User.deleteMany({});
  await Course.deleteMany({});

  const admin = await User.create({ name: 'Admin', email: 'admin@example.com', password: 'admin123', role: 'admin' });
  const prof = await User.create({ name: 'Prof. Rao', email: 'prof@example.com', password: 'prof123', role: 'professor' });
  const stu = await User.create({ name: 'Student Neha', email: 'student@example.com', password: 'student123', role: 'student' });

  const c1 = await Course.create({
    title: 'Data Structures',
    code: 'CSE201',
    department: 'CSE',
    description: 'Stacks, queues, trees, graphs',
    professor: prof._id
  });

  console.log('Seeded users:', { admin: admin.email, prof: prof.email, student: stu.email });
  console.log('Seeded course:', c1.title, c1.code);
  process.exit(0);
}

seed().catch(e => { console.error(e); process.exit(1); });
