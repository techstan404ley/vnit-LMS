import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Book, ClipboardList, FolderOpen, FileQuestion, Home } from "lucide-react";
import { useSearchParams, useNavigate } from "react-router-dom";

const Dashboard = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const role = searchParams.get("role");
  const year = searchParams.get("year");
  const branch = searchParams.get("branch");
  const semester = searchParams.get("semester");

  const contentModules = [
    {
      title: "Assignments",
      description: "View and submit your assignments",
      icon: ClipboardList,
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      title: "Reference Books",
      description: "Access recommended textbooks",
      icon: Book,
      color: "text-secondary",
      bgColor: "bg-secondary/10"
    },
    {
      title: "Notes",
      description: "Download course notes",
      icon: FileText,
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      title: "Materials",
      description: "Access study materials",
      icon: FolderOpen,
      color: "text-success",
      bgColor: "bg-success/10"
    },
    {
      title: "Previous Year Papers",
      description: "Practice with past papers",
      icon: FileQuestion,
      color: "text-warning",
      bgColor: "bg-warning/10"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-r from-primary to-secondary text-white p-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              {role === "professor" ? "Professor" : "Student"} Dashboard
            </h1>
            <p className="text-white/90">
              {year} Year • {branch} • Semester {semester}
            </p>
          </div>
          <Button
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
            onClick={() => navigate("/")}
          >
            <Home className="w-4 h-4 mr-2" />
            Home
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Available Content Modules
          </h2>
          <p className="text-muted-foreground">
            Select a module to access course materials
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {contentModules.map((module, index) => (
            <Card
              key={index}
              className="hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
            >
              <CardHeader>
                <div className={`w-14 h-14 rounded-lg ${module.bgColor} flex items-center justify-center mb-3`}>
                  <module.icon className={`w-7 h-7 ${module.color}`} />
                </div>
                <CardTitle className="text-xl">{module.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base mb-4">
                  {module.description}
                </CardDescription>
                <Button className="w-full">
                  Open Module
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
