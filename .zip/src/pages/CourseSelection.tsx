import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Calendar, GitBranch, BookOpen, ArrowRight } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";

const CourseSelection = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const role = searchParams.get("role") || "student";

  const [selectedYear, setSelectedYear] = useState<string | null>(null);
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);
  const [selectedSemester, setSelectedSemester] = useState<string | null>(null);

  const years = ["1st", "2nd", "3rd", "4th"];
  const branches = ["CSE", "ECE", "ME", "IT"];
  const semesters = ["1", "2", "3", "4", "5", "6", "7", "8"];

  const handleContinue = () => {
    if (selectedYear && selectedBranch && selectedSemester) {
      navigate(`/dashboard?role=${role}&year=${selectedYear}&branch=${selectedBranch}&semester=${selectedSemester}`);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8 text-foreground">
          Select Your Course
        </h1>

        <div className="space-y-6">
          {/* Select Year */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <Calendar className="w-6 h-6 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">Select Year</h2>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {years.map((year) => (
                <Button
                  key={year}
                  variant={selectedYear === year ? "default" : "outline"}
                  onClick={() => setSelectedYear(year)}
                  className="h-12"
                >
                  {year}
                </Button>
              ))}
            </div>
          </Card>

          {/* Select Branch */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <GitBranch className="w-6 h-6 text-secondary" />
              <h2 className="text-xl font-semibold text-foreground">Select Branch</h2>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {branches.map((branch) => (
                <Button
                  key={branch}
                  variant={selectedBranch === branch ? "default" : "outline"}
                  onClick={() => setSelectedBranch(branch)}
                  className="h-12"
                  disabled={!selectedYear}
                >
                  {branch}
                </Button>
              ))}
            </div>
          </Card>

          {/* Select Semester */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <BookOpen className="w-6 h-6 text-accent" />
              <h2 className="text-xl font-semibold text-foreground">Select Semester</h2>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {semesters.map((sem) => (
                <Button
                  key={sem}
                  variant={selectedSemester === sem ? "default" : "outline"}
                  onClick={() => setSelectedSemester(sem)}
                  className="h-12"
                  disabled={!selectedBranch}
                >
                  {sem}
                </Button>
              ))}
            </div>
          </Card>

          {/* Continue Button */}
          <Button
            onClick={handleContinue}
            disabled={!selectedYear || !selectedBranch || !selectedSemester}
            className="w-full h-14 text-lg"
            size="lg"
          >
            Continue to Dashboard
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CourseSelection;
